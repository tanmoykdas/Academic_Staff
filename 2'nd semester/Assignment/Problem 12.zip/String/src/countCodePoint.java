public class countCodePoint {
    public static void main(String[] args) {
        String str = "w3rsource.com";
        System.out.println("Original String : "+str);
        
        int count = str.codePointCount(2,10);
        
        System.out.println("Codepoint count = "+count);
    }
}
