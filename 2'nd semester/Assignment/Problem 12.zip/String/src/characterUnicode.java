public class characterUnicode {
    public static void main(String[] args) {
        String str = "w3resource.com";
        System.out.println("Original String : "+str);
        
        int val1 = str.codePointAt(4);
        int val2 = str.codePointAt(7);

        System.out.println("Character(unicode point) = "+val1);
        System.out.println("Character(unicode point) = "+val2);
    }
}
