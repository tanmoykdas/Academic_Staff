public class stringLength {
    public static void main(String[] args){
        String str = "example.com";
        
        int len = str.length();
        
        System.out.println("The string length of '" +str+ "' is: " +len);
    }
}
