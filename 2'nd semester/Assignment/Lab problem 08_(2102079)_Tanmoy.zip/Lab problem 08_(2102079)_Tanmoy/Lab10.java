/*
 Write a Java program to display the first 10 natural numbers.

Expected Output :

The first 10 natural numbers are:                                                
                                                                                 
1                                                                                
2                                                                                
3                                                                                
4                                                                                
5                                                                                
6                                                                                
7                                                                                
8                                                                                
9                                                                                
10
 */
public class Lab10 
{
    public static void main(String[] args)
    {     
    int i;
	System.out.println ("The first 10 natural numbers are:\n");
	for (i=1;i<=10;i++)
	{      
		System.out.println (i);
	}
System.out.println ("\n");
}
}
